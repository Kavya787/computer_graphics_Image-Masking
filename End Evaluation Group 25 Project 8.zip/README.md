Build Files have not been deleted as we have kept our Mesh Models there

To run
cd build
cmake ..
make

./Inpaint -in input.obj -out output.obj -outfaces faces -upsample sample